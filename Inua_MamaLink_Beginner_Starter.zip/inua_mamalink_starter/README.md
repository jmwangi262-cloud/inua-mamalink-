# Inua MamaLink — beginner starter project

**Owner/idea:** Inua Slice Foods Ltd (proposed project)

**Status:** Learning demonstration, **not** a deployed community or healthcare pilot.
**Medical warning:** NOT for medical decisions. Do not enter names, phone numbers,
addresses, pregnancy details, health records, child information or identifiers.

## What it does
- Enter aggregated nutrition-supply requests/deliveries by week and ward.
- See counts and charts.
- View a simple **four-week average** demand forecast; this is not sophisticated AI.
- Download your aggregate data and summary as CSV.
- Switch between synthetic practice mode and an empty workspace.

## Simplest way to run it (no programming installation required)
1. Create a free GitHub account: https://github.com/signup
2. Create a repository called `inua-mamalink` (select Public only for this code, which has NO personal data).
3. Unzip this starter project on your computer.
4. On GitHub choose **Add file > Upload files** and upload `app.py`, `requirements.txt`, `sample_data.csv`, `LICENSE`, and `README.md` (not the ZIP itself).
5. Commit the files to your GitHub repository.
6. Sign into https://share.streamlit.io/ and connect GitHub.
7. Select **Create app** > **Yup, I have an app**. Choose your repo, branch `main`, and main file `app.py`.
8. Click Deploy, then open the Streamlit app link.
9. Start with synthetic Practice mode; later try Empty mode for non-identifying aggregate totals.
10. Download your CSV after editing; records in this version are only stored in your live browser session.

Official deploy guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## First exercises
1. Change the main title in `app.py` and commit it on GitHub.
2. Add a synthetic weekly record and check how the metrics change.
3. Go to Forecast, try a location with a different request volume.
4. Download the CSV and open it in Excel.
5. Explain the app to two colleagues and collect feedback; record actual dates/results if you do a genuine trial.

## CSV layout
`date,ward,group,item,requested,delivered`

Each row is an **aggregate supply count**, not an individual person's record.

## Critical limitations / funding honesty
The included `sample_data.csv` is **fictional**, and does not prove pilot success.
This starter app is not automatically connected to any real-time data source, lacks
persistent storage and user authentication, and uses a basic moving average.
A public code repository and live demo alone do not establish UNICEF eligibility.
A more advanced, validated technical feature and genuine field results may be needed.

## Licence
MIT; see LICENSE.
